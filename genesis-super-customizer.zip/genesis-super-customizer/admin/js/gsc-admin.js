(function( $ ) {
	'use strict';

	/**
	 * Dashboard-specific JavaScript source.
	 *
	 *
	 */

})( jQuery );
