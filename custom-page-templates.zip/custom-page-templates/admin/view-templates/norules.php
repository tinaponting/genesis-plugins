<script type="text/template" class="cptemplates-tpl" data-name="norules">
  <p><?= sprintf( '%s <a href="#" class="btn-add-rule">%s</a>', __( 'This template has no rules yet. Click to ', 'cptemplates' ), __( 'create one', 'cptemplates' ) ) ?></p>
</script>    
