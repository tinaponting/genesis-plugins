# Genesis Extender Change Log

https://cobaltapps.com/downloads/genesis-extender-plugin/

## [1.9.4] - 2018-08-02
### Fixed
- Fixed Options Import admin check code to better accommodate all site setups.

## [1.9.3] - 2018-08-02
### Fixed
- Fixed vulnerability in the Options Import functionality.

## [1.9.2] - 2018-07-11
### Fixed
- Added Custom Functions POST code to help prevent the possibility of malicious code from being saved.

## [1.9.1] - 2018-04-26
### Added
- Added exif_imagetype function for Genesis Extender Image Manager in cases where active server's PHP configuration does not provide it.
- Added Change Log file and link to Change Log file in Settings page.

## [1.9.0] - 2018-04-21
### Changed
- Moved Genesis Extender admin pages to their own sidebar section.
- Replaced old Image Uploader functionality with newer Image Manager page.


## Template for future logs. ##

## [9.0.0] - 2032-01-28
### Added
- Add example text.

### Changed
- Improve example text.

### Removed
- Remove example text.

### Fixed
- Fix example text.
