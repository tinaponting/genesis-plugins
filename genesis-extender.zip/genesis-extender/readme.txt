=== Genesis Extender ===

== Installation ==

1. Upload the entire 'genesis-extender' folder to the '/wp-content/plugins/' directory -- or just upload the ZIP package via 'Plugins > Add New > Upload' in your WP Admin
2. Activate the plugin through the 'Plugins' menu in WordPress
3. In your left-hand "Genesis Theme Settings" menu you'll find "Extender Settings" and "Extender Custom" admin pages, showing that the Plugin was successfully installed and activated
4. That's it!

Extender Support: http://extenderdocs.cobaltapps.com/

Contact Us: http://cobaltapps.com/contact-us/