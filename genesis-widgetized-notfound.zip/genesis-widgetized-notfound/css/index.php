<?php
/**
 * Do NOT edit the css files here or put custom styles in here! They will be deleted on 'Genesis Widgetized Not Found & 404' updates!
 *
 * For custom styles for 'Genesis Widgetized Not Found & 404'
 * please add them to your active child theme's stylesheet (you may need '!important' maybe for a few rules...).
 */
