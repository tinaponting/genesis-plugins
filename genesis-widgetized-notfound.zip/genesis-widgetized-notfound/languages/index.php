<?php
/**
 * Do not put custom translations here. They will be deleted on 'Genesis Widgetized Not Found & 404' updates!
 *
 * Keep custom 'Genesis Widgetized Not Found & 404' translations in '/wp-content/languages/genesis-widgetized-notfound/'
 */
