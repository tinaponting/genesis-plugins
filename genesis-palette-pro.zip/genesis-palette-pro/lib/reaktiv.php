<?php

class GP_Pro_Reaktiv
{

	/**
	 * This is our constructor
	 *
	 * @return GP_Pro_Reaktiv_Setup
	 */
	public function __construct() {

		// functions related to license activation / checks
		add_action		(	'admin_init',								array(	$this,	'edd_config_key'				)			);
		add_action		(	'wp_ajax_core_activate',					array(	$this,	'core_activate'					)			);
		add_action		(	'wp_ajax_core_deactivate',					array(	$this,	'core_deactivate'				)			);
		add_action		(	'wp_ajax_gppro_support_request',			array(	$this,	'gppro_support_request'			)			);

		// GP filters
		add_filter		(	'gppro_admin_block_add',					array(	$this,	'support_block'					),	999		);
		add_filter		(	'gppro_sections',							array(	$this,	'support_section'				),	10,	2	);

		add_filter		(	'gppro_buttons',							array(	$this,	'license_button_nag'			),	50		);

	}

	/**
	 * add support block to side
	 *
	 * @return
	 */

	public function support_block( $blocks ) {

		if ( false === apply_filters( 'gppro_show_support', true ) ) {
			return $blocks;
		}

		// display blocks if checks pass
		$blocks['support-info'] = array(
			'tab'		=> __( 'Support', 'gppro' ),
			'title'		=> __( 'Help &amp; Support', 'gppro' ),
			'slug'		=> 'support_section',
		);

		return $blocks;

	}

	/**
	 * add support section to side
	 *
	 * @return
	 */

	public function support_section( $sections, $class ) {

		$sections['support_section']	= array(

			'support-field-setup'	=> array(
				'title'		=> '',
				'data'		=> array(
					'support-email-widget'	=> array(
						'input'		=> 'support'
					),
				),
			),

			'plugin-core-license-area'	=> array(
				'title'		=> '',
				'data'		=> array(
					'plugin-core-license-title' => array(
						'title'		=> __( 'License Key', 'gppro' ),
						'text'		=> __( 'Enter your license key for Design Palette Pro.', 'gppro' ),
						'input'		=> 'divider',
						'style'		=> 'block-full'
					),
					'core-license-key-field'	=> array(
						'input'		=> 'license',
					),
				),
			),

		); // end section

		$sections['support_section']	= apply_filters( 'gppro_section_inline_support_section', $sections['support_section'], $class );

		return $sections;

	}

	/**
	 * license key input section
	 *
	 * @return
	 */

	static function license_input_fields() {
		// fetch the license data
		$data	= Genesis_Palette_Pro::license_data();
		// check each part
		$license	= ! empty( $data['license'] ) ? $data['license'] : '' ;
		$status		= ! empty( $data['status'] ) ? $data['status'] : '' ;

		// an empty
		$input	= '';
		// build markup
		$input	.= '<div class="gppro-input gppro-license-input">';
			$input	.= '<div class="gppro-input-wrap gppro-license-wrap gppro-input-fullwidth">';
			$input	.= self::license_key_display( $license, $status );
			$input	.= '</div>';
		$input	.= '</div>';
		// return it
		return $input;

	}

	/**
	 * license key fields
	 *
	 * @return
	 */
	static function license_key_display( $license, $status ) {

		$activate	= array(
			'process'	=> 'activate',
			'action'	=> 'core_activate',
			'button'	=> __( 'Activate License', 'gppro' )
		);

		$deactivate	= array(
			'process'	=> 'deactivate',
			'action'	=> 'core_deactivate',
			'button'	=> __( 'Deactivate License', 'gppro' )
		);

		// set up actions and button text based on current license status
		$setup		= empty( $status ) || $status !== 'valid' ? $activate : $deactivate;

		// build out form
		$form	= '';

		$form	.= '<form class="gppro-license-form gppro-core-license-form">';

			$form	.= wp_nonce_field( 'gppro_core_license_nonce', 'gppro_core_license_nonce', false, false );
			$form	.= '<p class="gppro-license-submit-item">';

				$form	.= '<input class="gppro-license-item widefat" type="password" value="'.$license.'" id="gppro-core-license" name="gppro-core-license" autocomplete="off" />';

				$form	.= '<input data-process="'.$setup['process'].'" data-action="'.$setup['action'].'" type="button" class="button-primary button-small gppro-license-button" value="'.$setup['button'].'">';

			$form	.= '</p>';

		$form	.= '</form>';

		return $form;

	}

	/**
	 * add reminder button
	 * @return [type] [description]
	 */
	public function license_button_nag( $buttons ) {

		$status	= Genesis_Palette_Pro::license_data( 'status' );

		if ( isset( $status ) && $status == 'valid' ) {
			return $buttons;
		}

		$buttons['license']	= array(
			'button-type'		=> 'link',
			'button-link'		=> menu_page_url( 'genesis-palette-pro', 0 ).'&section=support_section',
			'button-label'		=> __( 'Enter License Key', 'gppro' ),
			'button-class'		=> 'button button-warning button-license-nag',
			'image-class'		=> ''
		);

		return $buttons;

	}

	/**
	 * remove the potential BOM from a JSON response
	 *
	 * @param  [type] $text     [description]
	 * @return [type]           [description]
	 */
	public static function remove_utf8_bom( $text ) {

		// set up the BOM for the preg_replace check
		$bom    = pack( 'H*', 'EFBBBF' );

		// do the replacement
		$text   = preg_replace( '/^$bom/', '', $text );

		// return the response
		return $text;
	}

	/**
	 * abstract the license key check
	 *
	 * @return mixed API status
	 */

	static function api_license_key_check( $license, $process ) {

		if ( ! isset( $license ) || isset( $license ) && empty( $license ) ) {
			return false;
		}

		// data to send in our API request
		$api_params = array(
			'edd_action'=> $process,
			'license' 	=> $license,
			'item_name' => urlencode( GPP_ITEM_NAME ), // the name of our product in EDD
			'url'       => home_url()
		);

		// Call the custom API.
		$response = wp_remote_get( add_query_arg( $api_params, GPP_STORE_URL ), array( 'timeout' => 30, 'sslverify' => false ) );

		// make sure the response came back okay
		if ( is_wp_error( $response ) ) {
			$ret['success'] = false;
			$ret['errmsg']	= $response->get_error_message();
			$ret['errcode']	= 'API_REQUEST_FAIL';
			$ret['message']	= __( 'The activation server not available.', 'gppro' );
			echo json_encode($ret);
			die();
		}

		// decode the license data
		$license_val	= wp_remote_retrieve_body( $response );

		// make sure the response came back okay
		if ( ! $license_val || empty( $license_val ) ) {
			$ret['success'] = false;
			$ret['errcode']	= 'API_RETRIEVE_FAIL';
			$ret['message']	= __( 'The activation server did not return any information.', 'gppro' );
			echo json_encode($ret);
			die();
		}

		$license_data	= json_decode( self::remove_utf8_bom( $license_val ) );
		$license_status	= $license_data->license;

		return $license_status;

	}

	/**
	 * abstract the license verification
	 *
	 * @return
	 */

	static function api_license_verified( $license, $status ) {

		// create data storage array
		$base_settings['license']	= $license;
		$base_settings['status']	= $status;

		update_option( 'gppro_core_active', $base_settings );

		// create array for license check transient
		$lic_check['license']		= $status;
		$lic_check['item_name']		= GPP_ITEM_NAME;

		set_transient( 'gppro_core_license_check', $lic_check );

		return;

	}


	/**
	 * check wp-config for license key
	 *
	 * @return
	 */

	public function edd_config_key() {

		if ( ! defined( 'GPPRO_CORE_LICENSE_KEY' ) ) {
			return;
		}

		$current	= Genesis_Palette_Pro::license_data( 'status' );

		if( isset( $current ) && $current == 'valid' ) {
			return;
		}

		// run key check
		$status	= self::api_license_key_check( GPPRO_CORE_LICENSE_KEY, 'activate_license' );

		if ( $status !== 'valid' ) {
			return;
		}

		self::api_license_verified( GPPRO_CORE_LICENSE_KEY, $status );

		// set option key to hide settings field
		update_option( 'gppro_core_config_key', 'valid' );

		return;

	}

	/**
	 * load the support widget or the message about it
	 * @return [type] [description]
	 */
	static function support_display() {

		$status	= Genesis_Palette_Pro::license_data( 'status' );

		if ( isset( $status ) && $status == 'valid' ) {
			return self::support_widget();
		} else {
			return self::support_missing();
		}

	}

	/**
	 * build and display message for support widget
	 *
	 * @return
	 */
	static function support_missing() {

		$message	= __( 'You must have a valid license key to recieve support. Please enter your key in the field below.', 'gppro' );

		return '<div class="gppro-input gppro-support-input"><p><em>' . $message . '</em></p></div>';

	}

	/**
	 * build and display support widget
	 *
	 * @return
	 */
	static function support_widget() {
		// get the current user info
		$user	= self::get_support_userdata();

		// start building the form
		$input	= '';

		$input	.= '<div class="gppro-input gppro-support-input">';
		$input	.= '<p class="gppro-support-prompt">' . __( 'Fill out the form below to submit a help request to our support team and we\'ll be in touch shortly.', 'gppro' ) . '</p>';

			$input	.= '<form class="gppro-support-form">';
			$input	.= wp_nonce_field( 'gppro_support_nonce', 'gppro_support_nonce', false, false );

			$input	.= '<p class="gppro-support-field-group gppro-support-field-name">';
				$input	.= '<input type="text" id="gppro-support-name" name="gppro-support-name" class="widefat support-field" value="' . esc_attr( $user['name'] ) . '" required="required" />';
				$input	.= '<label for="gppro-support-name">'.__( 'Your Name', 'gppro' ).'</label>';
			$input	.= '</p>';

			$input	.= '<p class="gppro-support-field-group gppro-support-field-email">';
				$input	.= '<input type="email" id="gppro-support-email" name="gppro-support-email" class="widefat support-field" value="' . is_email( $user['email'] ) . '" required="required" />';
				$input	.= '<label for="gppro-support-email">'.__( 'Your Email Address', 'gppro' ).'</label>';
			$input	.= '</p>';

			$input	.= '<p class="gppro-support-field-group gppro-support-field-text">';
				$input	.= '<textarea id="gppro-support-text" name="gppro-support-text" class="widefat textarea-expand support-field" required="required"></textarea>';
				$input	.= '<label for="gppro-support-text">'.__( 'Please describe your issue.', 'gppro' ).'</label>';
			$input	.= '</p>';

			$input	.= '<p class="gppro-support-submit">';
				$input	.= '<input type="button" id="gppro-support-request" class="button-primary" name="gppro-support-request" value="'.__( 'Submit Request', 'gppro' ).'" />';
				$input	.= '<img src="' . admin_url() . '/images/loading.gif" class="gppro-processing support-processing" />';
			$input	.= '</p>';

			$input	.= '<p class="gppro-support-disclaimer">';
			$input	.= __( 'Please note this request will contain certain information such as current WordPress version, active theme and plugins, and other information. No passwords or other sensitive information will be shared.', 'gppro' );
			$input	.= '</p>';

		$input	.= '</form>';
		$input	.= '</div>';


		// return it
		return $input;

	}

	/**
	 * call activation
	 *
	 * @return Reaktiv_Activation
	 */

	public function core_activate() {

		// first delete any transients, just in case
		delete_transient( 'gppro_core_license_check' );

		// get variables posted via AJAX
		$license	= $_POST['license'];
		$nonce		= $_POST['nonce'];

		if( empty( $license ) ) {
			$ret['success'] = false;
			$ret['errcode']	= 'NO_LICENSE';
			$ret['message']	= __( 'No license key was submitted.', 'gppro' );
			echo json_encode($ret);
			die();
		}

		// run a quick security check
		if( empty( $nonce ) ) {
			$ret['success'] = false;
			$ret['errcode']	= 'NONCE_FAIL';
			$ret['message']	= __( 'The security key was not available.', 'gppro' );
			echo json_encode($ret);
			die();
		}

		// run key check
		$status	= self::api_license_key_check( $license, 'activate_license' );

		// not valid. I SAID NOT VALID
		if ( $status == 'invalid' ) {

			$ret['success'] = false;
			$ret['errcode']	= 'LICENSE_FAIL';
			$ret['message']	= __( 'This license key is not valid.', 'gppro' );
			echo json_encode($ret);
			die();

		}

		// license was good. LETS GO
		if ( $status == 'valid' ) {

			self::api_license_verified( $license, $status );

			$ret['success'] 	= true;
			$ret['errcode']		= null;
			$ret['widget']		= self::support_widget();
			$ret['bprocess']	= 'deactivate';
			$ret['baction']		= 'core_deactivate';
			$ret['button']		= __( 'Deactivate License', 'gppro' );
			$ret['message']		= __( 'This license key has been activated.', 'gppro' );
			echo json_encode($ret);
			die();
		}

		// somehow we got to the end...and we don't know how.
		$ret['success'] = false;
		$ret['errcode']	= 'ERROR_UNKNOWN';
		$ret['message']	= __( 'There was an unknown error.', 'gppro' );
		echo json_encode($ret);
		die();

	}

	/**
	 * call deactivation
	 *
	 * @return Reaktiv_Activation
	 */

	public function core_deactivate() {

		// first delete any transients, just in case
		delete_transient( 'gppro_core_license_check' );

		// get plugin items from DB
		$license	= Genesis_Palette_Pro::license_data( 'license' );

		// get variables posted via AJAX
		$nonce		= $_POST['nonce'];

		if( ! $license || empty( $license ) ) {
			$ret['success'] = false;
			$ret['errcode']	= 'NO_LICENSE';
			$ret['message']	= __( 'No license key was stored.', 'gppro' );
			echo json_encode($ret);
			die();
		}

		// run a quick security check
		if( empty( $nonce ) ) {
			$ret['success'] = false;
			$ret['errcode']	= 'NONCE_FAIL';
			$ret['message']	= __( 'The security key was not available.', 'gppro' );
			echo json_encode($ret);
			die();
		}

		// data to send in our API request
		$status	= self::api_license_key_check( $license, 'deactivate_license' );

		if ( $status !== 'deactivated' ) {
			$ret['success'] = false;
			$ret['errcode']	= 'LICENSE_FAIL';
			$ret['message']	= __( 'This license could not be deactivated.', 'gppro' );
			echo json_encode($ret);
			die();
		}

		// deactivation was good. LETS GO
		if ( $status == 'deactivated' ) {

			delete_option( 'gppro_core_active' );
			delete_option( 'gppro_core_config_key' );

			$ret['success'] 	= true;
			$ret['errcode']		= null;
			$ret['widget']		= self::support_missing();
			$ret['bprocess']	= 'activate';
			$ret['baction']		= 'core_activate';
			$ret['button']		= __( 'Activate License', 'gppro' );
			$ret['message']		= __( 'This license key has been deactivated.', 'gppro' );
			echo json_encode($ret);
			die();
		}

		// somehow we got to the end...and we don't know how.
		$ret['success'] = false;
		$ret['errcode']	= 'ERROR_UNKNOWN';
		$ret['message']	= __( 'There was an unknown error.', 'gppro' );
		echo json_encode($ret);
		die();

	}

	/**
	 * process the help request
	 *
	 * @return Reaktiv_Activation
	 *
	 * @since 1.0
	 */

	public function gppro_support_request() {

		// get variables posted via AJAX
		$name		= $_POST['name'];
		$email		= $_POST['email'];
		$text		= $_POST['text'];

		// bail if the reqired fields aren't there
		if ( empty( $name ) || empty( $email ) || empty( $text ) ) {
			$ret['success'] = false;
			$ret['error']	= 'MISSING_FIELDS';
			$ret['message']	= __( 'Required fields were not entered.', 'gppro' );
			echo json_encode($ret);
			die();
		}

		// put them in an array
		$userdata	= array(
			'name'		=> $name,
			'email'		=> $email,
			'text'		=> $text
		);

		// check our nonce. like a boss.
		check_ajax_referer( 'gppro_support_nonce', 'nonce' );

		// fetch the details
		$details	= self::get_help_details( $userdata );

		// send the email
		$process	= self::process_help_email( $details );

		// bail if the send failed
		if ( ! $process ) {
			$ret['success'] = false;
			$ret['error']	= 'SEND_FAILED';
			$ret['message']	= __( 'Sorry, but the support request could not be sent. Please send an email to help@reaktivstudios.com.', 'gppro' );
			echo json_encode( $ret );
			die();
		}

		// send back the response
		$ret['success']		= true;
		$ret['message']		= __('Success! Your request has been sent. You\'ll be hearing from us shortly.', 'gppro' );
		echo json_encode( $ret );
		die();

	}

	/**
	 * set the email to HTML format
	 */
	static function set_html_content_type() {
		return 'text/html';
	}

	/**
	 * send the support email
	 * @param  [type] $details [description]
	 * @return [type]          [description]
	 */
	static function process_help_email( $details ) {

		// bail without any details
		if ( ! $details ) {
			return false;
		}

		// switch to HTML format
		add_filter( 'wp_mail_content_type', array( __CLASS__, 'set_html_content_type' ) );

		$sendto = apply_filters( 'gppro_support_email', 'help@reaktivstudios.com' );

		if ( ! $sendto ) {
			return false;
		}

		// parse out list of plugins
		$plist = '';
		$plugins = $details['plugins'];
		foreach( $plugins as $plugin ):
			$pname = preg_replace( '/\/.*/', '', $plugin );
			$plist .= str_replace( '-', ' ', $pname ) . '<br />';
		endforeach;

		// email
		$headers = 'From: ' . $details['name'] . ' <' . $details['email'] . '>' . "\r\n" ;
		$message = '
		<html>
		<body>
		<h4><u>Support Request</u></h4>
		<table cellpadding="0" cellspacing="0" border="0">
			<tr>
				<th width="150" align="left" valign="top">Name:&nbsp;</th>
				<td width="600" valign="top">' . $details['name'] . '</td>
			</tr>
			<tr>
				<th width="150" align="left" valign="top">Email:&nbsp;</th>
				<td width="600" valign="top">' . $details['email'] . '</td>
			</tr>
			<tr>
				<th width="150" align="left" valign="top">Issue:&nbsp;</th>
				<td width="600" valign="top">' . wpautop( stripslashes( $details['text'] ) ) . '</td>
			</tr>
		</table>
		<h4><u>Site Details</u></h4>
		<table cellpadding="0" cellspacing="0" border="0">
			<tr>
				<th width="150" align="left" valign="top">License Key:&nbsp;</th>
				<td width="600" valign="top">' . $details['license'] . '</td>
			</tr>
			<tr>
				<th width="150" align="left" valign="top">Plugin Type:&nbsp;</th>
				<td width="600" valign="top">' . $details['type'] . '</td>
			</tr>
			<tr>
				<th width="150" align="left" valign="top">Plugin Version:&nbsp;</th>
				<td width="600" valign="top">' . $details['version'] . '</td>
			</tr>
			<tr>
				<th width="150" align="left" valign="top">Site URL:&nbsp;</th>
				<td width="600" valign="top">' . $details['site'] . '</td>
			</tr>
			<tr>
				<th width="150" align="left" valign="top">Theme Name:&nbsp;</th>
				<td width="600" valign="top">' . $details['theme'] . '</td>
			</tr>
			<tr>
				<th width="150" align="left" valign="top">Theme Version:&nbsp;</th>
				<td width="600" valign="top">' . $details['thmver'] . '</td>
			</tr>
			<tr>
				<th width="150" align="left" valign="top">WP Version:&nbsp;</th>
				<td width="600" valign="top">' . $details['wpver'] . '</td>
			</tr>
			<tr>
				<th width="150" align="left" valign="top">PHP Version:&nbsp;</th>
				<td width="600" valign="top">' . $details['phpver'] . '</td>
			</tr>
			<tr>
				<th width="150" align="left" valign="top">Current Plugins:&nbsp;</th>
				<td width="600" valign="top">'. $plist . '</td>
			</tr>
		</table>
		</body>
		</html>
		';

		// get our title based on what license they have
		$prefix	= ! empty( $details['type'] ) && $details['type'] == 'Design Palette Pro Deluxe' ? 'Priority Ticket - ' : '';

		// send the actual email
		$send	= wp_mail( $sendto, $prefix . 'Design Palette Pro Support Request', trim( $message ), $headers );

		if ( ! $send ) {
			return false;
		}

		 // reset content-type
		remove_filter( 'wp_mail_content_type', array( __CLASS__, 'set_html_content_type' ) );

		// return a true so we can move forward
		return true;

	}

	/**
	 * [get_help_details description]
	 * @param  array  $data [description]
	 * @return [type]       [description]
	 */
	static function get_help_details( $data = array() ) {
		// parse the data from the user
		$name	= ! empty( $data['name'] ) ? esc_attr( $data['name'] ) : '';
		$email	= ! empty( $data['email'] ) ? is_email( $data['email'] ) : '';
		$text	= ! empty( $data['text'] ) ? esc_attr( $data['text'] ) : '';

		// fetch our license key
		$license	= Genesis_Palette_Pro::license_data( 'license' );

		// get some extra data so we can actually figure this out
		$version	= GPP_VER;
		$type		= GPP_ITEM_NAME;
		$site		= get_bloginfo( 'url' );
		$theme		= get_option( 'current_theme' );
		$thmver		= self::get_theme_version( $theme );
		$wpver		= get_bloginfo( 'version' );
		$phpver		= phpversion();
		$plugins	= get_option( 'active_plugins' );

		// array that shit.
		$details = array(
			'license'	=> $license,
			'name'		=> $name,
			'email'		=> $email,
			'text'		=> $text,
			'type'		=> esc_attr( $type ),
			'version'	=> $version,
			'site'		=> esc_url( $site ),
			'theme'		=> esc_attr( $theme ),
			'thmver'	=> $thmver,
			'wpver'		=> $wpver,
			'phpver'	=> $phpver,
			'plugins'	=> $plugins
		);

		// send it back
		return $details;
	}

	/**
	 * [get_support_userdata description]
	 * @return [type] [description]
	 */
	static function get_support_userdata() {
		// call the current user
		global $current_user;
		get_currentuserinfo();
		// set an array
		$userdata	= array(
			'name'	=> $current_user->display_name,
			'email'	=> $current_user->user_email,
		);
		// send it back
		return $userdata;
	}

	/**
	 * [get_theme_version description]
	 * @param  string $theme [description]
	 * @return [type]        [description]
	 */
	static function get_theme_version( $theme = 'Genesis' ) {

		// first parent Genesis
		if ( $theme == 'Genesis' && defined( 'PARENT_THEME_VERSION' ) ) {
			return PARENT_THEME_VERSION;
		}

		// now child theme
		if ( $theme != 'Genesis' && defined( 'CHILD_THEME_VERSION' ) ) {
			return CHILD_THEME_VERSION;
		}

		// didnt have defined or otherwise
		return 'unknown';

	}

} /// end class

new GP_Pro_Reaktiv();
