<?php

// Start up the engine
class GP_Pro_Admin
{

	/**
	 * This is our constructor
	 *
	 * @return void
	 *
	 * @since 1.0
	 */
	public function __construct() {
		add_action			(	'admin_enqueue_scripts',					array(	$this,	'admin_styles'			)			);
		add_action			(	'admin_enqueue_scripts',					array(	$this,	'admin_scripts'			)			);
		add_action			(	'admin_init', 								array(	$this,	'register_settings'		) 			);
		add_action			(	'admin_init',								array(	$this,	'protection_files'		)			);
		add_action			(	'admin_menu',								array(	$this,	'admin_menu'			) 			);
		add_action			(	'admin_notices',							array(	$this,	'viewable_notice'		)			);
		add_filter			(	'admin_body_class',							array(	$this,	'admin_body_class'		)			);
		add_filter			(	'option_page_capability_gppro-settings',	array(	$this,	'user_permission'		)			);
		add_filter			(	'admin_footer_text',						array(	$this,	'admin_footer'			)			);
		add_filter			(	'upload_mimes',								array(  $this,	'favicon_mime_type'		)			);
	}

	/**
	 * add a custom body class on the admin page for easier JS targeting
	 * @param  [type] $classes [description]
	 * @return [type]          [description]
	 */
	public function admin_body_class( $classes ) {

		$screen	= get_current_screen();

		if ( $screen->base == 'genesis_page_genesis-palette-pro' ) {
			$classes .= 'gppro-admin-page';
		}

		return $classes;

	}

    /**
     * allow .ico and .gif files to be uploaded in the native
     * WP media manager
     *
     * @param  [array]  $mimes  the currently allowed MIME types
     * @return [array]  $mimes  the updated array of allowed MIME types
     */
    public function favicon_mime_type( $mimes ) {
		// check for gif support
		if ( ! isset( $mimes['gif'] ) ) {
			$mimes['gif'] = 'image/gif';
		}
		// check for ico support
		if ( ! isset( $mimes['ico'] ) ) {
			$mimes['ico'] = 'image/x-icon';
		}
		// send back array of MIME types
		return $mimes;
    }

	/**
	 * call admin CSS
	 *
	 * @return mixed
	 */

	public function admin_styles() {
		// get current screen
		$screen	= get_current_screen();
		// bail if we aren't on our page or the object doesnt exist
		if ( ! is_object( $screen ) || $screen->base !== 'genesis_page_genesis-palette-pro' ) {
			return;
		}
		// load CSS that is not affected by script_debug
		wp_enqueue_style( 'wp-color-picker' );
		// set our prefix
		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '.css' : '.min.css';
		// load files in either minified or non-minified versions as requested
		wp_enqueue_style( 'gppro-admin', plugins_url( 'css/admin' . $suffix, __FILE__ ), array(), GPP_VER, 'all' );

	}

	/**
	 * call admin JS files
	 *
	 * @return mixed
	 */
	public function admin_scripts() {
		// get current screen
		$screen	= get_current_screen();
		// bail if we aren't on our page or the object doesnt exist
		if ( ! is_object( $screen ) || $screen->base !== 'genesis_page_genesis-palette-pro' ) {
			return;
		}
		// get our custom colorpicker file based on WP version
		$picker	= version_compare( get_bloginfo( 'version' ), '4.0', '>=' ) ? 'dpp-picker.4.0' : 'dpp-picker.3.9';
		// set our prefix
		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '.js' : '.min.js';
		// unregister the default colorpicker
		wp_deregister_script( 'wp-color-picker' );
		// register our patched one
		wp_register_script( 'wp-color-picker', plugins_url( 'js/ext/'.$picker.$suffix, __FILE__ ), array( 'iris' ), false, true );
		// load media pieces for uploaders
		wp_enqueue_media();
		// load files in either minified or non-minified versions as requested
		wp_enqueue_script( 'screenfull', plugins_url( 'js/ext/screenfull'.$suffix, __FILE__ ), array( 'jquery' ), '1.1.1', true );
		wp_enqueue_script( 'wp-color-picker' );
		wp_localize_script( 'wp-color-picker', 'wpColorPickerL10n', array(
			'clear' => __( 'Clear' ),
			'defaultString' => __( 'Default' ),
			'pick' => __( 'Select Color' ),
			'current' => __( 'Current Color' ),
		));
		wp_enqueue_script( 'gppro-preview', plugins_url( 'js/preview'.$suffix, __FILE__ ), array( 'jquery' ), GPP_VER, true );
		wp_enqueue_script( 'gppro-admin', plugins_url( 'js/admin'.$suffix, __FILE__ ), array( 'wp-color-picker', 'jquery-ui-core', 'jquery-ui-slider', 'jquery-ui-tooltip', 'jquery' ), GPP_VER, true );
		wp_localize_script( 'gppro-admin', 'adminData', array(
			'colorchoice'		=> apply_filters( 'gppro_picker_defaults', true ),
			'gfontlink'			=> '//fonts.googleapis.com/css?family=',
			'clearconfirm'		=> __( 'Are you sure you want to delete all the settings?', 'gppro' ),
			'errormessage'		=> __( 'There was an error parsing your data.', 'gppro' ),
			'supporterror'		=> __( 'Please see the areas in red.', 'gppro' ),
			'uploadtitle'		=> __( 'Upload Your Header Image', 'gppro' ),
			'favicontitle'		=> __( 'Upload Your Favicon file', 'gppro' ),
			'uploadbutton'		=> __( 'Attach', 'gppro' ),
			'tooltip_my'		=> apply_filters( 'gppro_tooltip_pos_my', 'left+15 center' ),
			'tooltip_at'		=> apply_filters( 'gppro_tooltip_pos_at', 'right center' ),
			'base_font_size'	=> GP_Pro_Helper::base_font_size(),
			'use_rems'			=> GP_Pro_Helper::rems_enabled(),
			'basepreview'		=> is_ssl() ? home_url( '/', 'https' ) : home_url( '/', 'http' )
		));

		// turn off heartbeat
		wp_deregister_script( 'heartbeat' );

	}

	/**
	 * add attribution link to settings page
	 *
	 * @return string $text
	 */

	public function admin_footer( $text ) {

		$screen = get_current_screen();

		if ( 'genesis_page_genesis-palette-pro' !== $screen->base ) {
			return $text;
		}

		// set our footer link with GA campaign tracker
		$link	= 'http://reaktivstudios.com/?utm_source=plugin&utm_medium=link&utm_campaign=dpp';

		// build footer
		$text	= sprintf( __( '<span id="footer-thankyou">This plugin brought to you by the fine folks at <a href="%1$s" title="%2$s" target="_blank">Reaktiv Studios</a></span>', 'gppro' ), esc_url( $link ), esc_html( 'Reaktiv Studios', 'gppro' ) );

		// run through filter
		$text	= apply_filters( 'gppro_admin_footer_text', $text );

		// return it
		return $text;
	}

	/**
	 * Register settings
	 *
	 * @return void
	 */

	public function register_settings() {
		register_setting( 'gppro-settings', 'gppro-settings' );

	}

	/**
	 * filter user permission to allow saving without error message
	 *
	 * @return void
	 */

	public function user_permission( $capability ) {

		return apply_filters( 'gppro_caps', $capability );

	}

	/**
	 * call settings page
	 *
	 * @return mixed
	 */

	public function admin_menu() {
		add_submenu_page( 'genesis', __( 'Genesis Design Palette Pro', 'gppro' ), __( 'Design Palette Pro', 'gppro' ), apply_filters( 'gppro_caps', 'manage_options' ), 'genesis-palette-pro', array( $this, 'admin_page' ) );

	}

	/**
	 * load admin page
	 *
	 * @return mixed
	 */

	public function admin_page() {

		$title	= __( 'Genesis Design Palette Pro', 'gppro' );
		$title	= apply_filters( 'gppro_admin_title', $title );

		$blocks	= GP_Pro_Setup::blocks();

		if ( ! $blocks ) {
			return;
		}

		echo '<div class="wrap gppro-wrap">';
		echo '<div class="icon32" id="icon-options-general"><br></div>';

			echo '<h2 class="gppro-admin-title">'.esc_attr( $title ).'</h2>';

			echo '<div class="gppro-settings-wrapper">';

				echo '<div class="gppro-block gppro-actions gppro-actions-top">';
					echo GP_Pro_Setup::buttons();
				echo '</div>';

				echo '<div class="gppro-block gppro-options">';

					echo '<div class="gppro-tabs gppro-column">';
						echo GP_Pro_Setup::tabs( $blocks );
					echo '</div>';

					echo '<div class="gppro-sections gppro-column">';
						echo GP_Pro_Sections::sections( $blocks );
					echo '</div>';

				echo '</div>';

				echo '<div class="gppro-block gppro-actions gppro-actions-bottom">';
					echo GP_Pro_Setup::buttons();
				echo '</div>';

			echo '</div>';

			echo GP_Pro_Setup::preview_block();

		echo '</div>';

	}

	/**
	 * checks to make sure the file is viewable and displays a message
	 * @return [type] [description]
	 */
	public function viewable_notice() {

		// first make sure we have our main class. not sure how we wouldn't but then again...
		if ( ! class_exists( 'Genesis_Palette_Pro' ) ) {
			return;
		}

		// now check to make sure we're on our settings page
		if ( ! isset( $_GET['page'] ) || isset( $_GET['page'] ) && $_GET['page'] !== 'genesis-palette-pro' ) {
			return;
		}

		// check we have any data at all first
		$data	= get_option( 'gppro-settings' );

		// check for empty
		if ( empty ( $data ) ) {
			return;
		}

		// get our file and bail if it doesn't exist
		$file	= Genesis_Palette_Pro::filebase( 'url' );

		if ( ! $file ) {
			return;
		}

		// check our ignore flag
		if ( get_option( 'gppro-warning-writeable' ) ) {
			return;
		}

		// check our access
		$view	= Genesis_Palette_Pro::file_access_check( $file );

		// show message if view check fails
		if ( ! $view ) {

			echo '<div id="message" class="error fade below-h2 gppro-admin-warning gppro-admin-warning-writeable"><p>';
			echo '<strong>'.__( '<strong>NOTICE:</strong> The generated CSS file is not accessible. Please check your server settings.', 'gppro' ).'</strong>';
			echo '<span class="ignore" data-child="writeable">' . __( 'Ignore this message', 'gppro' ) . '</span>';
			echo '</p></div>';

			return;
		}

		return;

	}

	/**
	 * Creates blank index.php and .htaccess files
	 *
	 * This function runs approximately once per month in order to ensure all folders
	 * have their necessary protection files
	 *
	 * @since 1.0.0.0
	 * @return void
	 */

	static function protection_files() {

		if ( ! class_exists( 'Genesis_Palette_Pro' ) )
			return;

		if ( false === get_transient( 'gppro_check_protection_files' ) ) :

			// grab our folder setup
			$folder	= Genesis_Palette_Pro::filebase( 'root' );
			if ( ! isset( $folder ) )
				return;

			// kill the trailing slash
			if( substr( $folder, -1 ) == '/' )
				$folder = substr( $folder, 0, -1 );

			// Top level blank index.php
			if ( ! file_exists( $folder . '/index.php' ) )
				@file_put_contents( $folder . '/index.php', '<?php' . PHP_EOL . '// Silence is golden.' );

			// Top level .htaccess file
			if ( ! file_exists( $folder . '/.htaccess' ) )
				@file_put_contents( $folder . '/.htaccess', self::get_htaccess() );

			// Check for the files once per day
			set_transient( 'gppro_check_protection_files', true, 3600 * 24 );

		endif;

	}

	/**
	 * [get_htaccess description]
	 * @return string the data for the htaccess file
	 */
	static function get_htaccess() {

		$data = 'Options -Indexes'."\n";
		$data .= 'RewriteEngine on'."\n";
		$data .= 'RewriteCond %{REQUEST_URI} !\.(css)$ [NC]'."\n";
		$data .= 'RewriteRule .* - [F,L]'."\n";

		$file	= apply_filters( 'gppro_htaccess_content', $data );

		return $file;

	}

/// end class
}
