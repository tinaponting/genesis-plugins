<?php

class GP_Pro_Builder {

	/**
	 * run checks for field data in CSS builder
	 *
	 * @return bool|mixed
	 */
	static function build_check( $data, $field ) {
		// bail if no data or field came through
		if ( ! isset( $data ) || ! isset( $data[ $field ] ) ) {
			return false;
		}
		// set the key / value pair as a single variable and
		// pass the single value data to compare and return
		return self::compare_single_field( $data[ $field ], $field );
	}

	/**
	 * confirms a default value exists when the always_write arg
	 * is set to avoid ajax notice errors
	 *
	 * @param  string $field	the field name being checked
	 * @return bool          	a true or false
	 */
	static function always_write_check( $field = '' ) {
		// fetch the default
		$default	= GP_Pro_Helper::get_default( $field );
		// return true or false based on default being there
		return ! $default ? false : true;
	}

	/**
	 * run the comparison of a single value against the default
	 * value provided
	 *
	 * @param  string $item  	the value being passed
	 * @param  string $field	the field name being checked
	 * @return bool          	a true or false
	 */
	static function compare_single_field( $item = '', $field = '' ) {
		// run an empty check on non-numeric values
		if ( empty( $item ) && ! is_numeric( $item ) ) {
			return false;
		}
		// check for filter bypassing default check
		if ( false === apply_filters( 'gppro_compare_default', $field ) ) {
			return true;
		}
		// fetch the default
		$default	= GP_Pro_Helper::get_default( $field );
		// run a comparison check on non-numeric values
		if ( ! is_numeric( $item ) && $item === $default ) {
			return false;
		}
		// run a comparison check on numeric values
		if ( is_numeric( $item ) && intval( $item ) === intval( $default ) ) {
			return false;
		}
		// return true since all checks passed
		return true;
	}

	/**
	 * small helper to get CSS values from font stack array
	 *
	 * @return bool|mixed
	 */

	static function stack_css( $selector, $value, $important = false ) {

		// check and set important flag
		$exmark	= $important === true ? ' !important' : '';

		// fetch our list of stacks
		$stacks	= GP_Pro_Helper::stacks();

		// merge all font stack types into a single array (only supports 2-dimensional array)
		$stacks = call_user_func_array( 'array_merge', $stacks );

		if ( ! isset( $stacks[ $value ] ) ) {
			return false;
		}

		if ( ! isset( $stacks[ $value ]['css'] ) ) {
			return false;
		}

		// make sure we don't have an extra semicolon
		$stack	= str_replace( ';', '', $stacks[ $value ]['css'] );

		return esc_attr( $selector ) . ': ' . $stack . $exmark . '; ';

	}

	/**
	 * small helper to make sure hex CSS values are done correctly
	 *
	 * @return string|bool
	 */

	static function hexcolor_css( $selector, $value, $important = false ) {

		// first remove possible duplicate hash
		$value	= preg_replace( '/#+/', '#', $value );

		// check and set important flag
		$exmark	= $important === true ? ' !important' : '';

		// check if there is a single hash
		if ( preg_match( '/^#[a-f0-9]{6}$/i', $value ) ) { //hex color is valid
			return esc_attr( $selector ).': '.$value.$exmark.'; ';
		}

		// check for missing hash
		if ( preg_match( '/^[a-f0-9]{6}$/i', $value ) ) { //hex color is valid
			return esc_attr( $selector ).': #'.$value.$exmark.'; ';
		}

		// send back false if it failed
		return false;

	}

	/**
	 * small helper to make sure numeric CSS values are done correctly
	 *
	 * @return string
	 */

	static function number_css( $selector, $value, $important = false ) {

		// first strip it
		$numval	= GP_Pro_Helper::number_check( $value );

		// check and set important flag
		$exmark	= $important === true ? ' !important' : '';

		return esc_attr( $selector ).': '.intval( $numval ).$exmark.'; ';

	}

	/**
	 * small helper to make sure text CSS values are done correctly
	 *
	 * @return string
	 */

	static function text_css( $selector, $value, $important = false ) {

		// first strip it
		$textval	= GP_Pro_Helper::text_check( $value );

		// check and set important flag
		$exmark	= $important === true ? ' !important' : '';

		// send back both
		return esc_attr( $selector ).': '.esc_attr( strtolower( $textval ) ).$exmark.'; ';

	}


	/**
	 * small helper to make sure PX and REM values in CSS are done correctly
	 *
	 * @return mixed
	 */

	static function px_rem_css( $selector, $value, $important = false ) {

		/**
		 * Bail out to just pixels unless we filter to enable REMs
		 * REMs have been removed from Genesis and all child themes are being updated
		 */
		if ( ! GP_Pro_Helper::rems_enabled() ) {
			return self::px_css( $selector, $value, $important );
		}

		// first strip it
		$numval		= GP_Pro_Helper::number_check( $value );

		// check and set important flag
		$exmark	= $important === true ? ' !important' : '';

		// bypass calcs and return without suffix for zeros
		if ( intval( $numval ) === 0 ) {
			return esc_attr( $selector ).': ' . $numval . $exmark . '; ';
		}

		// get the base font size for calcs
		$base	= GP_Pro_Helper::base_font_size();

		// make both calculations
		$pix_val	= intval( $numval );
		$rem_val	= intval( $numval ) / $base;

		// send back both
		return esc_attr( $selector ) . ': ' . $pix_val . 'px' . $exmark . '; ' . esc_attr( $selector ) . ': ' . round( $rem_val, 4 ) . 'rem' . $exmark . '; ';

	}


	/**
	 * small helper to make sure PX (without REM ) values in CSS are done correctly
	 *
	 * @return mixed
	 */

	static function px_css( $selector, $value, $important = false ) {

		/**
		 * All px_rem_css calls have been replaced with px_css
		 * This allows rems to still work if the filter is activated.
		 * However it will use rems anywhere pixels are used.
		 */
		if ( GP_Pro_Helper::rems_enabled() ) {
			return self::px_rem_css( $selector, $value, $important );
		}

		// first strip it
		$numval	= GP_Pro_Helper::number_check( $value );

		// check and set important flag
		$exmark	= $important === true ? ' !important' : '';

		// bypass and return without suffix for zero
		if ( intval( $numval ) === 0 ) {
			return esc_attr( $selector ).': '.intval( $numval ).$exmark.'; ';
		}

		// send back
		return esc_attr( $selector ).': '.intval( $numval ).'px'.$exmark.'; ';

	}


	/**
	 * small helper to make sure numeric CSS percentage values are done correctly
	 *
	 * @return mixed
	 */

	static function pct_css( $selector, $value, $important = false ) {

		// first strip it
		$numval	= GP_Pro_Helper::number_check( $value );

		// check and set important flag
		$exmark	= $important === true ? ' !important' : '';

		// bypass and return without suffix for zero
		if ( intval( $numval ) === 0 ) {
			return esc_attr( $selector ).': '.intval( $numval ).$exmark.'; ';
		}

		return esc_attr( $selector ).': '.intval( $numval ).'%'.$exmark.'; ';

	}

	/**
	 * small helper to handle image CSS build
	 *
	 * @return string
	 */

	static function image_css( $selector, $value, $position, $important = false ) {

		// check and set important flag
		$exmark	= $important === true ? ' !important' : '';
		$css = '';

		if ( 'none' !== $value ) {
			$css = esc_attr( $selector ) . ': url( "' . esc_url( $value ) . '") ' . esc_attr( $position ) . $exmark . '; ';
		} else {
			$css = esc_attr( $selector ) . ': ' . esc_attr( $value ) . $exmark . '; ';
		}

		// send back image with proper position
		return $css;

	}

	/**
	 * small helper to handle generic CSS build
	 *
	 * @return string
	 */

	static function generic_css( $selector, $value, $important = false ) {

		// check and set important flag
		$exmark	= $important === true ? ' !important' : '';

		// send back both
		return esc_attr( $selector ).': '.esc_attr( $value ).$exmark.'; ';

	}

	/**
	 * Generate 3 sided borders for comments
	 *
	 * @return string
	 */

	public static function comment_borders( $selector, $value, $important = false ) {

		// check and set important flag
		$exmark	= $important === true ? ' !important' : '';
		$css = '';

		switch ( $selector ) {
			case 'border-color':
				$css .= self::hexcolor_css( 'border-top-color', $value, $important );
				$css .= self::hexcolor_css( 'border-bottom-color', $value, $important );
				$css .= self::hexcolor_css( 'border-left-color', $value, $important );
				break;
			case 'border-style':
				$css .= self::text_css( 'border-top-style', $value, $important );
				$css .= self::text_css( 'border-bottom-style', $value, $important );
				$css .= self::text_css( 'border-left-style', $value, $important );
				break;
			case 'border-width':
				$css .= self::px_css( 'border-top-width', $value, $important );
				$css .= self::px_css( 'border-bottom-width', $value, $important );
				$css .= self::px_css( 'border-left-width', $value, $important );
				break;
			default:
				$css .= '';
				break;
		}

		return $css;

	}

	/**
	 * run the compiled CSS through cssTidy
	 * @param  [type] $build [description]
	 * @return [type]        [description]
	 */
	static function optimize_css( $build ) {

		// first check for the disabled option
		if ( false === apply_filters( 'gppro_enable_css_optimization', true ) ) {
			return $build;
		}

		// load cssTidy
		include( GPP_DIR . 'lib/tools/csstidy/class.csstidy.php' );

		// set an instance
		$tidy	= new csstidy();

		// bail if it didn't load
		if ( ! class_exists( 'csstidy' ) ) {
			return $build;
		}

		// set our default config
		$tidy->set_cfg( 'remove_last_;',	0	);
		$tidy->set_cfg( 'merge_selectors',	1	);
		$tidy->set_cfg( 'sort_properties',	3	);


		// allow for additional configs
		do_action( 'gppro_csstidy_config' );

		// parse it
		$tidy->parse( $build );

		// set our parsed item as a variable
		$parsed	= $tidy->print->plain();

		// remove linebreaks
		$parsed = str_replace( array( "\r", "\n" ), '', $parsed );

		// send it back
		return $parsed;

	}

	/**
	 * Build the selector
	 *
	 * @param  string|array $class
	 * @param  array $item
	 * @param  string $context 'build' or 'preview'
	 * @return string
	 */
	public static function build_selector( $class, $item, $context = 'preview' ) {
		$selector = '';
		$target = $item['target'];

		if ( ! empty( $item['body_override'] ) ) {
			if ( 'preview' == $context ) {
				$class = $item['body_override']['preview'];
			} else {
				$class = $item['body_override']['front'];
			}
		}

		// if we have an array of targets
		if ( is_array( $target ) ) {
			$last = count( $target );
			$i = 0;
			foreach ( $target as $each_target ) {
				// Allow multiple body_overrides
				if ( is_array( $class ) ) {
					$last_class = count( $class );
					$c = 0;
					foreach ( $class as $class_item ) {
						$selector .= $class_item . ' ' . $each_target;
						if ( ++$c !== $last_class ) {
							$selector .= ', ';
						}
					}
				} else {
					$selector .= $class . ' ' . $each_target;
				}
				if ( ++$i !== $last ) {
					$selector .= ', ';
				}
			}
		} else {
			if ( ! empty( $target ) ) {
				if ( is_array( $class ) ) {
					$last_class = count( $class );
					$c = 0;
					foreach ( $class as $class_item ) {
						$selector .= $class_item . ' ' . $target;
						if ( ++$c !== $last_class ) {
							$selector .= ', ';
						}
					}
				} else {
					$selector = $class . ' ' . $target;
				}
			} else {
				$selector = $class;
			}
		}

		return $selector;
	}

	public static function set_build_callback_args( $id, $style, $data ) {
		$args = array(
			$style['selector'],
			$data[ $id ]
		);

		if ( 'GP_Pro_Builder::image_css' == $style['builder'] ) {
			$args[] = $style['image_position'];
		}

		if ( ! empty( $style['important'] ) ) {
			$args[] = true;
		}

		return $args;
	}

	public static function build_responsive( $class, $queries, $data ) {
		$css = '';
		$last_target = '';
		$open_brace = false;
		foreach ( $queries as $query => $styles ) {
			$css .= $query . " {\n";
			foreach ( $styles as $id => $style ) {
				$selector = self::build_selector( $class, $style, 'build' );

				$args = self::set_build_callback_args( $id, $style, $data );

				// If we're on the first valid rule
				if ( ! $last_target ) {
					$css .= '  ' . $selector . " { ";
					$open_brace = true;
					$last_target = $selector;
					$css .= call_user_func_array( $style['builder'], $args );
				// if we're starting a new group of rules
				} elseif ( $last_target !== $selector ) {
					$css .= "}\n";
					$css .= '  ' . $selector . " { ";
					$open_brace = true;
					$last_target = $selector;
					$css .= call_user_func_array( $style['builder'], $args );
				// if we're already in a rule group
				} else {
					$last_target = $selector;
					$css .= call_user_func_array( $style['builder'], $args );
				}
			}
			// Catch any unclosed braces
			if ( $open_brace ) {
				$css .= "}\n";
			}
			/**
			 * Deprecated filter
			 */
			$css  = apply_filters( 'gppro_css_inline_responsive_wide', $css, $data, $class );
			$css .= "}\n";
		}

		if ( $css ) {
			$css = "/* responsive elements */\n" . $css;
		}

		return $css;
	}

	/**
	 * DEPRECATED
	 *
	 * This was only used for the header images and was removed in 1.3.0.
	 *
	 * @param  string $class
	 * @param  array $styles
	 * @param  array $data
	 * @return string
	 */
	public static function build_retina( $class, $styles, $data ) {

		$css = '';
		$last_target = '';
		$open_brace = false;

		if ( $styles ) {
			$css .= "@media only screen and (-webkit-min-device-pixel-ratio: 1.5),\n";
			$css .= "\tonly screen and (-moz-min-device-pixel-ratio: 1.5),\n";
			$css .= "\tonly screen and (-o-min-device-pixel-ratio: 3/2),\n";
			$css .= "\tonly screen and (min-device-pixel-ratio: 1.5) { \n\n";

			foreach ( $styles as $id => $style ) {
				$selector = self::build_selector( $class, $style, 'build' );

				$args = self::set_build_callback_args( $id, $style, $data );

				// If we're on the first valid rule
				if ( ! $last_target ) {
					$css .= '  ' . $selector . " { ";
					$open_brace = true;
					$last_target = $selector;
					$css .= call_user_func_array( $style['builder'], $args );
				// if we're starting a new group of rules
				} elseif ( $last_target !== $selector ) {
					$css .= "}\n";
					$css .= '  ' . $selector . " { ";
					$open_brace = true;
					$last_target = $selector;
					$css .= call_user_func_array( $style['builder'], $args );
				// if we're already in a rule group
				} else {
					$last_target = $selector;
					$css .= call_user_func_array( $style['builder'], $args );
				}
			}
			// Catch any unclosed braces
			if ( $open_brace ) {
				$css .= "}\n";
			}
			// check for inline add-ons
			$css	= apply_filters( 'gppro_css_inline_retina_specific', $css, $data, $class );

			$css .= "}\n";
		}

		if ( $css ) {
			$css = "/* retina elements */\n" . $css;
		}

		return $css;
	}

	/**
	 * DEPRECATED
	 *
	 * These builder filters are no longer used.
	 * Left in just in case anyone was using them.
	 *
	 * @param  array $data
	 * @param  string $class
	 * @return string
	 */
	public static function backcompat_filters( $data, $class ) {
		$css  = '';
		$css .= apply_filters( 'gppro_css_inline_general_body', $css, $data, $class );
		$css .= apply_filters( 'gppro_css_inline_header_area', $css, $data, $class );
		$css .= apply_filters( 'gppro_css_inline_navigation', $css, $data, $class );
		$css .= apply_filters( 'gppro_css_inline_home_content', $css, $data, $class );
		$css .= apply_filters( 'gppro_css_inline_post_content', $css, $data, $class );
		$css .= apply_filters( 'gppro_css_inline_content_extras', $css, $data, $class );
		$css .= apply_filters( 'gppro_css_inline_comments_area', $css, $data, $class );
		$css .= apply_filters( 'gppro_css_inline_main_sidebar', $css, $data, $class );
		$css .= apply_filters( 'gppro_css_inline_footer_widgets', $css, $data, $class );
		$css .= apply_filters( 'gppro_css_inline_footer_main', $css, $data, $class );
		return $css;
	}

	/**
	 * build out the CSS by calling each sections individual builder function
	 * @return string CSS
	 */
	public static function build_css() {

		// fetch our data
		$data	= get_option( 'gppro-settings' );

		// run pre-build filter on the data itself
		$data	= apply_filters( 'gppro_css_builder_data', $data );

		// bail if we have no data
		if ( ! $data ) {
			return false;
		}

		// run our custom action before
		do_action( 'gppro_before_css_builder', $data );

		// fetch the body class, possibly filtered
		$class	= apply_filters( 'gppro_body_class', 'gppro-custom' );
		$class	= 'body.' . esc_attr( $class );

		$setup	= '';
		$responsive = array();
		$retina = array();

		// setup our CSS build
		$sections = GP_Pro_Sections::get_section_items();

		foreach ( $sections as $tab => $tab_group ) {
			$last_target = '';
			$open_brace = false;
			foreach ( $tab_group as $key => $section ) {
				// Only continue if we've got some CSS to write
				if ( ! empty( $section['data'] ) ) {
					$styles = $section['data'];
					foreach ( $styles as $id => $style ) {

						// Skip if this isn't a setting that needs to write a style
						if ( ! isset( $style['builder'] ) ) {
							continue;
						}

						// check to make sure a default exists if the always_write is set
						if ( ! empty( $style['always_write'] ) && ! self::always_write_check( $id ) ) {
							continue;
						}

						// Bail if default matches AND the field doesn't have the always flag
						if ( empty( $style['always_write'] ) && ! self::build_check( $data, $id ) ) {
							continue;
						}

						// handle responsive styles
						if ( isset( $style['media_query'] ) ) {
							$responsive[ $style['media_query'] ][ $id ] = $style;
							continue;
						}

						// handle retina
						if ( isset( $style['image'] ) && 'retina' == $style['image'] ) {
							$retina[ $id ] = $style;
							continue;
						}

						$selector = self::build_selector( $class, $style, 'build' );

						$args = self::set_build_callback_args( $id, $style, $data );

						// If we're on the first valid rule
						if ( ! $last_target ) {
							$setup .= $selector . " {\n";
							$open_brace = true;
							$last_target = $selector;
							$setup .= '  ';
							$setup .= call_user_func_array( $style['builder'], $args );
							$setup .= "\n";
						// if we're starting a new group of rules
						} elseif ( $last_target !== $selector ) {
							$setup .= " }\n";
							$setup .= $selector . " {\n";
							$open_brace = true;
							$last_target = $selector;
							$setup .= '  ';
							$setup .= call_user_func_array( $style['builder'], $args );
							$setup .= "\n";
						// if we're already in a rule group
						} else {
							$last_target = $selector;
							$setup .= '  ';
							$setup .= call_user_func_array( $style['builder'], $args );
							$setup .= "\n";
						}
					}
				}
			}
			// Catch any unclosed braces
			if ( $open_brace ) {
				$setup .= " }\n";
			}
		}

		$setup .= self::build_responsive( $class, $responsive, $data );
		$setup .= self::build_retina( $class, $retina, $data );
		$setup .= self::backcompat_filters( $data, $class );

		// grab any custom CSS and include it
		$build	= apply_filters( 'gppro_css_builder', $setup, $data, $class );

		// run the compiled CSS through cssTidy unless disabled
		$build	= self::optimize_css( $build );

		// run our custom action after
		do_action( 'gppro_after_css_builder', $data, $build );

		// add our CSS header stamp
		$header	= self::css_header_stamp();

		// combine them
		$css	= $header . $build;

		return $css;

	}

	/**
	 * set up the CSS header stamp
	 *
	 * @return string
	 */
	static function css_header_stamp() {

		$header	= '/*'."\n";
		$header	.= "\t" .'Genesis Design Palette Pro v' . GPP_VER . "\n";
		$header	.= "\t" .'CSS generated ' . date( 'r', time() ) . "\n";
		$header	.= '*/'."\n\n";

		// allow it to be filtered
		return apply_filters( 'gppro_css_file_header', $header );
	}

} // end class
