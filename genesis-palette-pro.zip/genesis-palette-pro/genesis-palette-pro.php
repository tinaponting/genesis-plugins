<?php
/*
Plugin Name: Genesis Design Palette Pro
Description: Introducing a New Way to Style Genesis Themes. Requires the Genesis framework.
Version: 1.3.4
License: GPLv2
*/
if( ! defined( 'GPP_BASE' ) ) {
	define( 'GPP_BASE', plugin_basename(__FILE__) );
}

if( ! defined( 'GPP_DIR' ) ) {
	define( 'GPP_DIR', plugin_dir_path( __FILE__ ) );
}

if( ! defined( 'GPP_VER' ) ) {
	define( 'GPP_VER', '1.3.4' );
}

if( ! defined( 'GPP_STORE_URL' ) ) {
	define( 'GPP_STORE_URL', 'https://genesisdesignpro.com' );
}

if( ! defined( 'GPP_ITEM_NAME' ) ) {
	define( 'GPP_ITEM_NAME', 'Design Palette Pro Plus' );
}

if( ! class_exists( 'EDD_SL_Plugin_Updater' ) ) {
	include( 'lib/EDD_SL_Plugin_Updater.php' );
}

// Start up the engine
class Genesis_Palette_Pro
{
	/**
	 * Static property to hold our singleton instance
	 * @var Genesis_Palette_Pro
	 *
	 * @since 1.0
	 */
	static $instance = false;

	/**
	 * Hold default styles (use get_defaults to access them)
	 * @var Genesis_Palette_Pro
	 *
	 * @since 1.0
	 */
	private $defaults;

	/**
	 * This is our constructor, which is private to force the use of
	 * getInstance() to make this a Singleton
	 *
	 * @return Genesis_Palette_Pro
	 *
	 * @since 1.0
	 */

	private function __construct() {
		// Load Upgrades
		require_once( GPP_DIR . 'lib/upgrade.php' );

		add_action			(	'plugins_loaded',						array(	$this,	'textdomain'			)			);
		add_action			(	'plugins_loaded',						array(	$this,	'disable_addons'		),	1		);
		add_action			(	'plugins_loaded',						array(	$this,	'load_themes'			)			);
		add_action			(	'init', 								array(	$this,	'preview_admin_bar'		) 			);
		add_action			(	'init',									array(	$this,	'plugin_compat'			),	1		);
		add_action			(	'set_current_user',						array(	$this,	'preview_logout'		)			);
		add_action			(	'wp_enqueue_scripts',					array(	$this,	'front_scripts'			),	9999	);
		add_action			(	'wp_enqueue_scripts',					array(	$this,	'preview_assets'		),	9999	);

		add_action			(	'admin_init',							array(	$this,	'export_styles'			)			);
		add_action			(	'admin_init',							array(	$this,	'import_styles'			)			);
		add_action			(	'admin_notices',						array(	$this,	'export_notices'		)			);
		add_action			(	'admin_notices',						array(	$this,	'import_notices'		)			);
		add_action			(	'wp_before_admin_bar_render',			array(	$this,	'admin_bar_item'		),	99		);

		add_filter			(	'body_class',							array(	$this,	'body_class'			)			);
		add_filter			(	'plugin_action_links',					array(	$this,	'quick_link'			),	10,	2	);

		// AJAX calls
		add_action			(	'wp_ajax_save_styles',					array(	$this,	'save_styles'			)			);
		add_action			(	'wp_ajax_clear_styles',					array(	$this,	'clear_styles'			)			);
		add_action			(	'wp_ajax_ignore_warning',				array(	$this,	'ignore_warning'		)			);
		add_action			(	'wp_ajax_ignore_webfont',				array(	$this,	'ignore_webfont'		)			);

		// genesis specific
		add_action			(	'genesis_init',							array(	$this,	'load_admin'			),	20		);
		add_action			(	'genesis_admin_menu',					array(	$this,	'settings_menu'			),	20		);
		add_filter			(	'genesis_pre_load_favicon',				array(	$this,	'user_favicon'			)			);

		// activation hooks
		register_activation_hook	( __FILE__,							array(	$this,	'activate'				)			);
		register_deactivation_hook	( __FILE__,							array(	$this,	'clear_check'			)			);

		// FILTERCEPTION
		add_filter			(	'gppro_webfont_stacks',					array(	$this,	'lato_webfont'			)			);
		add_action			(	'after_setup_theme',					array(	$this,	'enable_custom_header'	)			);
		add_filter			(	'after_setup_theme',					array(	$this,	'link_decorations'		)			);
		add_filter			(	'gppro_section_inline_header_area',		array(	$this,	'header_item_check'		),	99,	2	);
		add_filter			(	'gppro_section_inline_content_extras',	array(	$this,	'pagination_check'		),	99,	2	);
		add_filter			(	'gppro_section_inline_comments_area',	array(	$this,	'jetpack_comments'		),	99,	2	);
		add_filter			(	'gppro_set_defaults',					array(	$this,	'genesis_defaults'		),	99,	2	);

		// EDD items
		add_action			(	'admin_init',							array(	$this,	'edd_core_update'		)			);

	}

	/**
	 * If an instance exists, this returns it.  If not, it creates one and
	 * returns it.
	 *
	 * @return Genesis_Palette_Pro
	 */

	public static function getInstance() {

		if ( !self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	/**
	 * load textdomain
	 *
	 * @return string load_plugin_textdomain
	 */

	public function textdomain() {

		load_plugin_textdomain( 'gppro', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );

	}

	/**
	 * Disable obsolete plugin extensions
	 *
	 * For all versions past 1.2.0, child theme addons are integrated with the core
	 * this deactivates them if they're found.
	 *
	 * @return
	 */
	public function disable_addons() {
		// Only disable on versions greater than 1.2.0
		if ( version_compare( GPP_VER, '1.2.0', '>=' ) ) {
			require_once( ABSPATH . 'wp-admin/includes/plugin.php' );

			if ( defined( 'GPMTP_VER' ) ) {
				deactivate_plugins( 'gppro-metro-pro/gppro-metro-pro.php' );
			}
			if ( defined( 'GPMIP_VER' ) ) {
				deactivate_plugins( 'gppro-minimum-pro/gppro-minimum-pro.php' );
			}
			if ( defined( 'GPELV_VER' ) ) {
				deactivate_plugins( 'gppro-eleven40-pro/gppro-eleven40-pro.php' );
			}
		}
	}

	/**
	 * Load Theme-specific functionality
	 *
	 * @return void
	 */
	public function load_themes() {

		require_once( GPP_DIR . 'lib/themes.php' );

	}

	/**
	 * reusable check for whether Genesis is active or not
	 *
	 * @return bool genesis template
	 */

	static function check_active() {

		$proper	= function_exists( 'genesis_load_framework' ) ? true : false;

		return $proper;

	}

	/**
	 * This function runs on plugin activation. It checks to make sure Genesis
	 * or a Genesis child theme is active. If not, it deactivates itself.
	 *
	 * @since 1.0.0
	 */

	public function activate() {

		$active	= self::check_active();

		if ( ! $active && ! is_network_admin() ) {
			$this->deactivate( '2.0.0', '3.7' );
		}

		// set the active flag
		$this->set_active_flag();

		return;

	}

	/**
	 * Deactivate plugin.
	 *
	 * This function deactivates the design panel.
	 *
	 * @since 1.0.0
	 *
	 * @return mixed $genesis_version $wp_version
	 */

	public function deactivate( $genesis_version = '2.0.0', $wp_version = '3.7' ) {

		deactivate_plugins( plugin_basename( __FILE__ ) );
		wp_die( sprintf( __( 'Sorry, you cannot run Design Palette Pro without WordPress %s and <a href="%s">Genesis %s</a> or greater.', 'gppro' ), $wp_version, 'https://genesisdesignpro.com/get/genesis', $genesis_version ) );

	}

	/**
	 * clear warning check setting
	 *
	 * @return void
	 */

	public function clear_check() {

		// delete the active setting
		delete_option( 'gppro_core_active' );

	}

	/**
	 * call front CSS and JS files
	 *
	 * @return mixed
	 */

	public function front_scripts() {

		$check	= self::check_active();
		$data	= get_option( 'gppro-settings' );

		if ( ! $check || ! $data ) {
			return;
		}

		$file	= $this->filebase();

		// make sure the file exists
		if ( ! file_exists( $file['dir'] ) ) {
			return;
		}

		// add the ability to bypass the loading completely
		if ( false === apply_filters( 'gppro_enable_style_load', true ) ) {
			return;
		}

		// if file exists, but isn't readable, bail to the manual
		if ( ! is_readable( $file['dir'] ) ) {
			add_action( 'wp_head', array( $this, 'front_style_head' ), 999 );
			return;
		}

		// check the file can be access in the browser
		$view	= self::file_access_check( $file['url'] );

		// if can't be accessed for some reason, bail to the manual
		if ( ! $view ) {
			add_action( 'wp_head', array( $this, 'front_style_head' ), 999 );
			return;
		}

		// Make protocol-relative URL
		$url = preg_replace( '#^https?://#', '//', $file['url'] );

		// all checks passed, show file
		wp_enqueue_style( 'gppro-style', $url , array(), filemtime( $file['dir'] ), 'all' );

	}

	/**
	 * make sure the file is accessible
	 * @param  string $file the URL of the CSS file
	 * @return bool true if viewable, false otherwise
	 */
	static function file_access_check( $file = '' ) {
		// bail without a file
		if ( empty( $file ) ) {
			return;
		}
		// begin check if transient is not present
		if ( false === $access = get_transient( 'gppro_check_file_access' ) ) {
			// set it true
			$access	= true;
			// first fetch the file
			$data	= wp_remote_get( $file );
			// bail if it's unable to fetch
			if ( is_wp_error( $data ) ) {
				$access	= false;
			}
			// pull out our response code
			$code	= wp_remote_retrieve_response_code( $data );
			// bail if its anything other than 200
			if ( is_wp_error( $code ) || empty( $code ) || ! empty( $code ) && $code !== 200 ) {
				$access	= false;
			}
			// store the access for a day
			set_transient( 'gppro_check_file_access', $access, DAY_IN_SECONDS );
		}

		return $access;
	}

	/**
	 * add admin bar item
	 *
	 * @return array $wp_admin_bar
	 */

	public function admin_bar_item() {

		global $wp_admin_bar;

		// run against our current user capability filter
		if ( ! current_user_can( apply_filters( 'gppro_caps', 'manage_options' ) ) ) {
			return $wp_admin_bar;
		}

		$wp_admin_bar->add_menu( array(
			'parent'	=> 'appearance',
			'id'		=> 'design-palette',
			'title'		=> __( 'Design Palette Pro', 'gppro' ),
			'href'		=> admin_url( 'admin.php?page=genesis-palette-pro' )
		) );

	}

	/**
	 * hide admin bar on preview pane
	 *
	 * @return bool show_admin_bar
	 */

	public function preview_admin_bar() {

		if ( isset( $_GET['gppro-preview'] ) ) {
			add_filter( 'show_admin_bar', '__return_false' );
		}

	}

	/**
	 * construct preview URL
	 *
	 * @return string $url
	 */
	static function preview_url() {

		// fetch user options
		$urlcheck	= self::plugin_option_check( 'gppro-user-preview-url' );
		$logcheck	= self::plugin_option_check( 'gppro-user-preview-type' );

		// check for SSL
		$scheme		= is_ssl() ? 'https' : 'http';

		// check against fallbacks
		$baseurl	= ! $urlcheck || empty( $urlcheck ) ? home_url( '/', $scheme ) : esc_url( $urlcheck );
		$loggedin	= ! $logcheck ? false : true;

		// set my main defaults
		$url	= array(
			'base'		=> $baseurl,
			'loggedin'	=> $loggedin
		);

		// pass through filter
		$url	= apply_filters( 'gppro_preview_url', $url );

		// return
		return $url;

	}

	/**
	 * add preview query string to iframe loaded content
	 *
	 * @return void preview
	 */
	public function preview_assets() {

		if ( ! isset( $_GET['gppro-preview'] ) ) {
			return;
		}

		$logcheck	= self::plugin_option_check( 'gppro-user-preview-type' );
		$loggedin	= empty( $logcheck ) ? false : true;

		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '.js' : '.min.js';

		wp_enqueue_script( 'gppro-links', plugins_url( 'lib/js/links'.$suffix, __FILE__), array( 'jquery' ), GPP_VER, true );
		wp_localize_script( 'gppro-links', 'previewLinks', array(
			'loggedin'	=> $loggedin
		));

		// turn off heartbeat
		wp_deregister_script( 'heartbeat' );

	}

	/**
	 * logout the iframe
	 *
	 * @return mixed $current_user preview_logout
	 */
	public function preview_logout() {

		if ( ! isset( $_GET['gppro-loggedout'] ) ) {
			return;
		}

		global $current_user;

		if( ! empty( $current_user ) && $current_user->ID > 0 ) {
			wp_set_current_user( 0 );
		}

	}

	/**
	 * check for various theme options to enable / disable functionality
	 *
	 * @return mixed genesis-settings
	 */
	static function theme_option_check( $option ) {

		$options	= get_option( 'genesis-settings' );

		if ( ! isset( $options[$option] ) ) {
			return false;
		}

		return $options[$option];

	}

	/**
	 * check for various plugin options to enable / disable functionality
	 *
	 * @return mixed gppro-settings
	 */
	static function plugin_option_check( $option ) {
		// fetch the option based on the variable passed
		$setting	= get_option( $option );
		// return false if setting is not present
		if ( empty( $setting ) ) {
			return false;
		}
		// return the setting requested
		return $setting;
	}

	/**
	 * Enable custom header support
	 *
	 * Enabled by default for Genesis and Genesis Sample themes.
	 *
	 * @uses gppro_enable_header_image_support
	 * @uses gppro_custom_header_args
	 *
	 * @since 1.3.1
	 * @return void
	 */
	public static function enable_custom_header() {
		if ( apply_filters( 'gppro_enable_header_image_support', 'genesis' == GP_Pro_Themes::get_selected_child_theme() ) ) {
			// Use WP custom header instead of Genesis' because its arguments aren't flexible enough.
			add_theme_support( 'custom-header',
				apply_filters( 'gppro_custom_header_args',
					array(
						'width'           => 360,
						'height'          => 60,
						'header-selector' => '.header-image .site-title > a',
						'header-text'     => false
					)
				)
			);
		}
	}

	/**
	 * [header_item_check description]
	 * @param  [type] $sections [description]
	 * @param  [type] $class [description]
	 * @return [type]        [description]
	 */
	static function header_item_check( $sections, $class ) {

		if ( get_header_image() ) {
			$sections['section-break-site-title']['break']['text'] =
			sprintf( __( 'Site title text options are disabled when a custom header image is active. Please remove the header image from <a href="%s">Appearance > Header</a> to enable these settings.', 'gppro' ), admin_url( 'themes.php?page=custom-header' ) );
			unset( $sections['site-title-text-setup']		);
			unset( $sections['site-title-padding-setup']	);
			// unset site description text settings for themes with normal site name / description setup
			if ( ! in_array( GP_Pro_Themes::get_selected_child_theme(), array( 'minimum-pro' ) ) ) {
				unset( $sections['section-break-site-desc']		);
				unset( $sections['site-desc-display-setup']		);
				unset( $sections['site-desc-type-setup']		);
			}
		}

		// run check for active header sidebar
		if ( ! is_active_sidebar( 'header-right' ) ) {

			unset( $sections['section-break-header-nav']		);
			unset( $sections['header-nav-color-setup']			);
			unset( $sections['header-nav-type-setup']			);
			unset( $sections['header-nav-item-padding-setup']	);
			unset( $sections['section-break-header-widgets']	);
			unset( $sections['header-widget-title-setup']		);
			unset( $sections['header-widget-content-setup']		);

			// add a message regarding Jetpack
			$sections['section-break-empty-header-widgets-setup']	= array(
				'break'	=> array(
					'type'	=> 'full',
					'title'	=> __( 'Header Widgets', 'gppro' ),
					'text'	=> __( 'There are currently no active items in the header widget area.', 'gppro' ),
				),
			);

		}

		// send it back
		return $sections;

	}

	/**
	 * check pagination option and display accordingly
	 *
	 * @return mixed $items
	 */
	/**
	 * [pagination_check description]
	 * @param  [type] $sections [description]
	 * @param  [type] $class    [description]
	 * @return [type]           [description]
	 */
	static function pagination_check( $sections, $class ) {

		$navtype	= self::theme_option_check( 'posts_nav' );

		if ( ! isset( $navtype ) || isset( $navtype ) && empty( $navtype ) ) {
			return $sections;
		}

		if ( $navtype == 'prev-next' ) {

			unset( $sections['extras-pagination-numeric-backs'] 		);
			unset( $sections['extras-pagination-numeric-colors'] 		);
			unset( $sections['extras-pagination-numeric-padding-setup'] );

		}

		if ( $navtype == 'numeric' ) {

			unset( $sections['extras-pagination-text-setup'] );

		}

		// send it back
		return $sections;

	}

	/**
	 * check for Jetpack comments and disable
	 *
	 * @return mixed $items Jetpack
	 */

	static function jetpack_comments( $sections, $class ) {

		if( class_exists( 'Jetpack' ) && Jetpack::is_module_active( 'comments' ) ) {

			unset( $sections['comment-reply-notes-setup']						);
			unset( $sections['section-break-comment-reply-atags-setup']			);
			unset( $sections['comment-reply-atags-area-setup']					);
			unset( $sections['comment-reply-atags-base-setup']					);
			unset( $sections['comment-reply-atags-code-setup']					);
			unset( $sections['section-break-comment-reply-fields']				);
			unset( $sections['comment-reply-fields-label-setup']				);
			unset( $sections['section-break-comment-reply-fields-input']		);
			unset( $sections['comment-reply-fields-input-layout-setup']			);
			unset( $sections['comment-reply-fields-input-color-base-setup']		);
			unset( $sections['comment-reply-fields-input-color-focus-setup']	);
			unset( $sections['comment-reply-fields-input-type-setup']			);
			unset( $sections['section-break-comment-submit-button']				);
			unset( $sections['comment-submit-button-color-setup']				);
			unset( $sections['comment-submit-button-type-setup']				);
			unset( $sections['comment-submit-button-spacing-setup']				);

			// add a message regarding Jetpack
			$sections['section-break-comments-jetpack-setup']	= array(
				'break'	=> array(
					'type'	=> 'full',
					'title'	=> __( 'Comment Form Fields', 'gppro' ),
					'text'	=> __( 'You are currently using Jetpack Comments, which cannot be custom styled.', 'gppro' ),
				),
			);


		}

		// send it back
		return $sections;

	}

	/**
	 * Add link decoration controls for supported themes
	 *
	 * Currently added for Genesis and Genesis Sample
	 *
	 * @since 1.3.1
	 * @return void
	 */
	public function link_decorations() {
		if ( 'genesis' == GP_Pro_Themes::get_selected_child_theme() ) {
			add_filter( 'gppro_sections', array( 'GP_Pro_Sections', 'link_decoration' ), 10, 2 );
		}
	}

	/**
	 * Add Genesis-specific defaults that don't apply to any child theme
	 *
	 * @since 1.3.1
	 * @param  array $defaults
	 * @return array
	 */
	public function genesis_defaults( $defaults ) {
		if ( 'genesis' == GP_Pro_Themes::get_selected_child_theme() ) {
			$defaults['post-header-meta-link-dec']       = 'none';
			$defaults['post-entry-link-dec']             = 'none';
			$defaults['post-footer-link-dec']            = 'none';
			$defaults['extras-read-more-link-dec']       = 'none';
			$defaults['extras-author-box-bio-link-dec']  = 'none';
			$defaults['comment-element-name-link-dec']   = 'none';
			$defaults['comment-element-date-link-dec']   = 'none';
			$defaults['comment-element-body-link-dec']   = 'none';
			$defaults['comment-element-reply-link-dec']  = 'none';
			$defaults['comment-reply-notes-link-dec']    = 'none';
			$defaults['sidebar-widget-content-link-dec'] = 'none';
			$defaults['footer-widget-content-link-dec']  = 'none';
			$defaults['footer-main-content-link-dec']    = 'none';
		}
		return $defaults;
	}

	/**
	 * load user favicon if provided
	 *
	 * @param  string	$favicon	the default URL
	 * @return string	$favicon	either the default or the user generated one
	 */
	public function user_favicon( $favicon ) {
		// check for file
		$user_icon	= self::plugin_option_check( 'gppro-site-favicon-file' );
		// load user set one or fetch default
		$favicon	= ! empty( $user_icon ) ? esc_url( $user_icon ) : $favicon;
		// return favicon
		return $favicon;
	}

	/**
	 * swap Lato source to native
	 *
	 * @return string $webfonts
	 */
	public function lato_webfont( $webfonts ) {

		$webfonts['lato']['src']	= 'native';

		return $webfonts;
	}

	/**
	 * set custom body class to apply styles
	 *
	 * @return string $classes
	 */

	public function body_class( $classes ) {

		$check	= self::check_active();

		// bail if we aren't running Genesis
		if ( ! $check ) {
			return $classes;
		}

		// check for and add the 'preview' class
		if ( isset( $_GET['gppro-preview'] ) ) {
			$classes[]	= 'gppro-preview';
		}

		// check our other filter for custom one not tied to the builder
		$alt_class	= apply_filters( 'gppro_alt_body_class', false );
		if ( ! empty( $alt_class ) ) {
			$classes[]	= esc_attr( $alt_class );
		}

		// run our settings file check
		$data = get_option( 'gppro-settings' );

		// bail if we have no data
		if ( ! $data ) {
			return $classes;
		}

		// check our filter, then throw the custom class on there
		$custom		= apply_filters( 'gppro_body_class', 'gppro-custom' );
		$classes[]	= esc_attr( $custom );

		return $classes;
	}

	/**
	 * helper function to check and set active flag on activation
	 *
	 * @return null
	 */
	public function set_active_flag() {

		// first check if we have it
		$coreactive	= get_option( 'gppro_core_active' );

		if ( ! $coreactive ) {
			update_option( 'gppro_core_active', true );
		}

		return;

	}

	/**
	 * Public API for getting style defaults
	 *
	 * @return array $defaults
	 */
	public function get_defaults() {

		return $this->defaults;
	}

	/**
	 * run our active checks and load files if applicable
	 * @return void
	 */
	public function load_admin() {

		// run our active check (again)
		$check	= self::check_active();

		if ( ! $check ) {
			return;
		}

		// we're all clear - load our files
		require_once( GPP_DIR . 'lib/setup.php'		);
		require_once( GPP_DIR . 'lib/admin.php'		);
		require_once( GPP_DIR . 'lib/sections.php'	);
		require_once( GPP_DIR . 'lib/builder.php'	);
		require_once( GPP_DIR . 'lib/helper.php'	);
		require_once( GPP_DIR . 'lib/reaktiv.php'	);

		// Set style defaults
		if ( class_exists( 'GP_Pro_Helper' ) ) {
			$this->defaults = GP_Pro_Helper::set_defaults();
		}

		// set our flag
		$this->set_active_flag();

	}

	/**
	 * Instantiate the class to create the menu.
	 *
	 * @since 1.0.0
	 *
	 * @return GP_Pro_Admin
	 */

	public function settings_menu() {

		$check	= self::check_active();

		if ( ! $check || ! is_admin() ) {
			return;
		}

		new GP_Pro_Admin;

	}

	/**
	 * [active_license description]
	 * @return [type] [description]
	 */
	static function active_license() {

		$active	= get_option( 'gppro_core_active' );

		if ( ! $active ) {
			return false;
		}

	}

	/**
	 * return the general link or the license directed if missing
	 * @return [type] [description]
	 */
	static function quick_link_url() {

		// run the active license check
		$check	= self::license_data( 'status' );

		if ( ! $check || $check == 'none' || $check == 'invalid' ) {
			return '<a href="' . menu_page_url( 'genesis-palette-pro', 0 ) . '&section=support_section">' . __( 'Enter License Key', 'gppro' ) . '</a>';
		} else {
			return '<a href="' . menu_page_url( 'genesis-palette-pro', 0 ) . '">' . __( 'Settings', 'gppro' ) . '</a>';
		}

	}

	/**
	 * show settings link on plugins page
	 *
	 * @return string $links
	 */

	public function quick_link( $links, $file ) {

		static $this_plugin;

		if ( ! $this_plugin ) {
			$this_plugin = plugin_basename( __FILE__ );
		}

		// check to make sure we are on the correct plugin
		if ( $file == $this_plugin ) {

			$quicklink	= self::quick_link_url();
			array_push( $links, $quicklink );

		}

		return $links;

	}

	/**
	 * set filename and create folder if need be for reuse
	 * @param  [type] $key [description]
	 * @return [type]      [description]
	 */
	static function filebase( $key = false ) {

		$uploads	= wp_upload_dir();
		$basedir	= $uploads['basedir'].'/gppro/';
		$baseurl	= $uploads['baseurl'].'/gppro/';

		// check if folder exists. if not, make it
		if ( ! is_dir( $basedir ) ) {
			mkdir( $basedir );
		}

		// set the CHMOD in case
		chmod( $basedir, 0755 );

		// open the css file, or generate if one does not exist
		$blog_id	= get_current_blog_id();
		$filename	= 'gppro-custom-'.$blog_id.'.css';

		// set up our two file types
		$dirfile	= $basedir.$filename;
		$urlfile	= $baseurl.$filename;

		// send it back
		$data	= array(
			'root'	=> $basedir,
			'dir'	=> $dirfile,
			'url'	=> $urlfile,
		);

		// send back the entire data array if no key is present
		if ( ! $key ) {
			return $data;
		}

		// send back just the one item
		return $data[$key];

	}

	/**
	 * generate our CSS file, with checks for multisite
	 *
	 * @return bool
	 */

	public static function generate_file( $create ) {

		do_action( 'gppro_before_create' );

		$file	= self::filebase();

		$check	= fopen( $file['dir'], 'wb');

		if ( $check === false ) {
			return false;
		}

		$write	= trim( $create );
		fwrite( $check, $write );
		fclose( $check );

		do_action( 'gppro_after_create' );

		return true;

	}

	/**
	 * load the CSS manually in the head if the file isn't readable
	 * @return [type] [description]
	 */
	public function front_style_head() {

		if ( ! class_exists( 'GP_Pro_Builder' ) ) {
			return;
		}

		$css	= GP_Pro_Builder::build_css();

		if ( ! $css ) {
			return;
		}

		echo '<style media="all" type="text/css">'.$css.'</style>';

		return;

	}

	/**
	 * take the passed user choices and do various
	 * data validation and sanitiation before
	 * saving and passing to the CSS build
	 *
	 * @param  array  $choices [description]
	 * @return [type]          [description]
	 */
	public function save_style_settings( $choices = array(), $always = array() ) {
		// handle our before action
		do_action( 'gppro_before_save', $choices );
		// fetch our current saved data
		$current	= get_option( 'gppro-settings' );
		// assuming we have some, save it as a backup
		if ( ! empty( $current ) ) {
			update_option( 'gppro-settings-backup', $current );
		}
		// if we don't have our builder class, just save it and return
		if ( ! class_exists( 'GP_Pro_Builder' ) ) {
			// update the data
			update_option( 'gppro-settings', $choices );
			// handle our after action
			do_action( 'gppro_after_save', $choices );
			// and finish
			return;
		}
		// set an empty array of our updated values
		$updated	= array();
		// loop our choices to get our key / value pair
		foreach( $choices as $key => $value ) {
			// run our build check to not save defaults
			$compare	= GP_Pro_Builder::compare_single_field( $value, $key );
			// if we passed, add it into our array OR is part of the ignore array
			if ( ! empty( $compare ) || in_array( $key, $always ) ) {
				$updated[$key]	= $value;
			}
		}
		// bail if no data is different
		if ( empty( $updated ) ) {
			return;
		}
		// update the data
		update_option( 'gppro-settings', $updated );
		// handle our after action
		do_action( 'gppro_after_save', $updated );
		// and finish
		return;
	}

	/**
	 * save our settings that aren't related to styles, such as
	 * favicon and header images
	 *
	 * @param  array  $choices 	the full array of settings being passed
	 * @return array  $choices 	the updated array of settings with the specific user settings removed
	 */
	public function save_user_settings( $choices = array() ) {
		// check for favicon
		if ( ! empty( $choices['site-favicon-file'] ) ) {
			update_option( 'gppro-site-favicon-file', esc_url( $choices['site-favicon-file'] ) );
		} else {
			delete_option( 'gppro-site-favicon-file' );
		}
		// check for user preview URL
		if ( ! empty( $choices['user-preview-url'] ) ) {
			update_option( 'gppro-user-preview-url', esc_url( $choices['user-preview-url'] ) );
		} else {
			delete_option( 'gppro-user-preview-url' );
		}
		// check for user logged in choice
		if ( ! empty( $choices['user-preview-type'] ) ) {
			update_option( 'gppro-user-preview-type', true );
		} else {
			delete_option( 'gppro-user-preview-type' );
		}
		// remove the three options from the array
		unset( $choices['site-favicon-file'] );
		unset( $choices['user-preview-url'] );
		unset( $choices['user-preview-type'] );
		// return the remaining array
		return $choices;
	}

	/**
	 * save our new CSS stylesheet via AJAX
	 *
	 * @return void
	 */
	public function save_styles() {
		// check for styles being passed through
		if ( ! isset( $_POST['choices'] ) || isset( $_POST['choices'] ) && empty( $_POST['choices'] ) ) {
			$ret['success'] = false;
			$ret['errcode'] = 'NO_DATA';
			$ret['message'] = __( 'No data was provided.', 'gppro' );
			echo json_encode( $ret );
			die();
		}
		// get the data passed
		$choices	= $_POST['choices'];
		$always		= ! empty( $_POST['always'] ) ? (array) $_POST['always'] : array();
		$nonce		= $_POST['nonce'];
		// verify our nonce
		wp_verify_nonce( 'gppro_save_nonce', 'nonce' );
		// pass the data to store our non-style options
		$choices	= $this->save_user_settings( $choices );
		// send to our save function
		$this->save_style_settings( $choices, $always );
		// check for the builder class
		if ( ! class_exists( 'GP_Pro_Builder' ) ) {
			// return JSON array with error code if the builder class is missing
			$ret['success'] = false;
			$ret['errcode'] = 'NO_CLASS';
			$ret['message'] = __( 'The required file to write CSS is missing. Please reinstall or contact support.', 'gppro' );
			echo json_encode($ret);
			die();
		}
		// get the new CSS
		$build	= GP_Pro_Builder::build_css();
		// bail if our builder failed
		if ( $build == false ) {
			// return JSON array with error code if the CSS could not be generated
			$ret['success'] = false;
			$ret['errcode'] = 'NO_CSS';
			$ret['message'] = __( 'The CSS could not be generated', 'gppro' );
			echo json_encode($ret);
			die();
		}
		// generate the CSS
		$generate	= self::generate_file( $build );
		// bail if the file could be be generated
		if ( $generate === false ) {
			// return JSON array with error code if the folder for the CSS was not writable
			$ret['success'] = false;
			$ret['errcode'] = 'NOT_WRITEABLE';
			$ret['message'] = __( 'The plugin folder is not writable.', 'gppro' );
			echo json_encode( $ret );
			die();
		} else {
			// delete our transient for access checking
			delete_transient( 'gppro_check_file_access' );
			// return our JSON array as true with the message
			$ret['success'] 	= true;
			$ret['message'] 	= __( 'Success! Your new style is saved.', 'gppro' );
			echo json_encode( $ret );
			die();
		}
		// we've reached the end, and nothing worked....
		$ret['success'] = false;
		$ret['errcode'] = 'UNKNOWN';
		$ret['message'] = __( 'There was an unknown error.', 'gppro' );
		echo json_encode( $ret );
		die();
	}

	/**
	 * clear our settings and delete the CSS file
	 *
	 * @return void
	 */

	public function clear_styles() {

		// get the data passed
		$nonce		= $_POST['nonce'];

		wp_verify_nonce( 'gppro_save_nonce', 'nonce' );

		// back up current
		$current	= get_option( 'gppro-settings' );

		update_option( 'gppro-settings-backup', $current );
		delete_option( 'gppro-settings' );
		delete_option( 'gppro-webfont-alert' );

		$file	= $this->filebase();

		if ( file_exists( $file['dir'] ) ) {
			unlink ( $file['dir'] );
		}

		// action to allow deletion of other data by plugins, etc
		do_action( 'gppro_after_clear' );

		$ret['success']		= true;
		$ret['redirect']	= menu_page_url( 'genesis-palette-pro', 0 );
		$ret['message']		= __( 'Your style settings have been deleted.', 'gppro' );
		echo json_encode( $ret );
		die();

	}

	/**
	 * clear child theme warning
	 *
	 * @return void
	 */

	public function ignore_warning() {

		// get the data passed
		$child		= $_POST['child'];

		if ( ! isset( $child ) || isset( $child ) && empty( $child ) ) {

			$ret['success'] = false;
			$ret['errcode'] = 'NO_CHILD';
			$ret['message'] = __( 'No child theme name was given.', 'gppro' );
			echo json_encode( $ret );
			die();

		} else {

			update_option( 'gppro-warning-'.$child, true );

			$ret['success'] 	= true;
			$ret['message'] 	= __( 'OK', 'gppro' );
			echo json_encode( $ret );
			die();

		}

		// we've reached the end, and nothing worked....
		$ret['success'] = false;
		$ret['errcode'] = 'UNKNOWN';
		$ret['message'] = __( 'There was an unknown error.', 'gppro' );
		echo json_encode( $ret );
		die();

	}

	/**
	 * clear webfont pagespeed warning
	 *
	 * @return void
	 */

	public function ignore_webfont() {

		// get the data passed
		update_option( 'gppro-webfont-alert', 'ignore' );

		$ret['success'] 	= true;
		$ret['message'] 	= __( 'OK', 'gppro' );
		echo json_encode( $ret );
		die();

	}



	/**
	 * export our settings
	 *
	 * @return mixed
	 */

	public function export_styles() {

		// check page and query string
		if ( ! isset( $_GET['gppro-export'] ) || isset( $_GET['gppro-export'] ) && $_GET['gppro-export'] != 'go' ) {
			return;
		}

		// check nonce
		$nonce = $_GET['_wpnonce'];
		if ( ! wp_verify_nonce( $nonce, 'gppro_export_nonce' ) ) {
			return;
		}

		// get current settings
		$current	= get_option( 'gppro-settings' );

		// if settings empty, bail
		if ( empty( $current ) ) {
			$failure	= menu_page_url( 'genesis-palette-pro', 0 ).'&section=build_settings&export=failure&reason=nodata';
			wp_safe_redirect( $failure );

			return;
		}

		$output = json_encode( (array) $current );

		//* Prepare and send the export file to the browser
		header( 'Content-Description: File Transfer' );
		header( 'Cache-Control: public, must-revalidate' );
		header( 'Pragma: hack' );
		header( 'Content-type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="gppro-export-' . date( 'Ymd-His' ) . '.json"' );
		header( 'Content-Length: ' . mb_strlen( $output ) );
		echo $output;
		exit();

	}

	/**
	 * import our settings
	 *
	 * @return void
	 */

	public function import_styles() {

		// bail if no page reference
		if ( ! isset( $_GET['gppro-import'] ) || isset( $_GET['gppro-import'] ) && $_GET['gppro-import'] != 'go' ) {
			return;
		}

		// check nonce and bail if missing
		$nonce = $_POST['_wpnonce'];
		if ( ! wp_verify_nonce( $nonce, 'gppro_import_nonce' ) ) {
			return;
		}


		// bail if no file present
		if ( ! isset( $_FILES['gppro-import-upload'] ) ) {
			$failure	= menu_page_url( 'genesis-palette-pro', 0 ).'&section=build_settings&uploaded=failure&reason=nofile';
			wp_safe_redirect( $failure );

			return;
		}

		// bail if no file present
		if ( isset( $_FILES['gppro-import-upload']['error'] ) && $_FILES['gppro-import-upload']['error'] === 4 ) {
			$failure	= menu_page_url( 'genesis-palette-pro', 0 ).'&section=build_settings&uploaded=failure&reason=nofile';
			wp_safe_redirect( $failure );

			return;
		}

		// check file extension
		$name	= explode( '.', $_FILES['gppro-import-upload']['name'] );
		if ( end( $name ) !== 'json' ) {
			$failure	= menu_page_url( 'genesis-palette-pro', 0 ).'&section=build_settings&uploaded=failure&reason=notjson';
			wp_safe_redirect( $failure );

			return;
		}

		// passed our initial checks, now decode the file and check the contents
		$upload		= file_get_contents( $_FILES['gppro-import-upload']['tmp_name'] );
		$options	= json_decode( $upload, true );

		// check for valid JSON
		if ( $options === null ) {
			$failure	= menu_page_url( 'genesis-palette-pro', 0 ).'&section=build_settings&uploaded=failure&reason=badjson';
			wp_safe_redirect( $failure );

			return;
		}

		// everything is gold! lets make some magic
		$current	= get_option( 'gppro-settings' );

		update_option( 'gppro-settings-backup', $current );
		update_option( 'gppro-settings', $options );

		// check for existence of builder class
		if ( ! class_exists( 'GP_Pro_Builder' ) ) {

			$failure	= menu_page_url( 'genesis-palette-pro', 0 ).'&section=build_settings&uploaded=failure&reason=noclass';
			wp_safe_redirect( $failure );

			return;
		}

		// get the new CSS
		$create		= GP_Pro_Builder::build_css();

		if ( $create == false ) {

			$failure	= menu_page_url( 'genesis-palette-pro', 0 ).'&section=build_settings&uploaded=failure&reason=nocss';
			wp_safe_redirect( $failure );

			return;
		}

		$build	= self::generate_file( $create );

		//* Redirect, add success flag to the URI
		$update	= menu_page_url( 'genesis-palette-pro', 0 ).'&section=build_settings&uploaded=success';
		wp_safe_redirect( $update );

		exit;

	}

	/**
	 * display messages if export failure
	 *
	 * @return mixed Genesis_Palette_Pro
	 */

	public function export_notices() {

		// first check to make sure we're on our settings
		if ( ! isset( $_GET['page'] ) || isset( $_GET['page'] ) && $_GET['page'] !== 'genesis-palette-pro' ) {
			return;
		}

		// check for failure
		if ( isset( $_GET['export'] ) && isset( $_GET['reason'] ) && $_GET['export'] == 'failure' ) {

			$message	= __( 'There was an error with your export. Please try again later.', 'gppro' );

			// no file provided
			if ( $_GET['reason'] == 'nodata' ) {
				$message	= __( 'No settings data has been saved. Please save your settings and try again.', 'gppro' );
			}

			echo '<div id="message" class="error">';
			echo '<p>'.esc_attr( $message ).'</p>';
			echo '</div>';

			return;

		}

		return;

	}

	/**
	 * display messages if import success or failure
	 *
	 * @return mixed Genesis_Palette_Pro
	 */

	public function import_notices() {

		// first check to make sure we're on our settings
		if ( ! isset( $_GET['page'] ) || isset( $_GET['page'] ) && $_GET['page'] !== 'genesis-palette-pro' ) {
			return;
		}

		// make sure we have some sort of upload message
		if ( ! isset( $_GET['uploaded'] ) ) {
			return;
		}

		// check for failure
		if ( isset( $_GET['uploaded'] ) && isset( $_GET['reason'] ) && $_GET['uploaded'] == 'failure' ) {

			// set a default message
			$message	= __( 'There was an error with your import. Please try again later.', 'gppro' );

			// no file provided
			if ( $_GET['reason'] == 'nofile' ) {
				$message	= __( 'No file was provided. Please try again.', 'gppro' );
			}

			// file isn't JSON
			if ( $_GET['reason'] == 'notjson' ) {
				$message	= __( 'The import file was not in JSON format. Please try again.', 'gppro' );
			}

			// JSON isn't valid
			if ( $_GET['reason'] == 'badjson' ) {
				$message	= __( 'The import file was not valid JSON. Please try again.', 'gppro' );
			}

			// builder class is missing
			if ( $_GET['reason'] == 'noclass' ) {
				$message	= __( 'The required file for generating CSS is missing from the plugin. Please reinstall or contact support.', 'gppro' );
			}

			// no CSS generated
			if ( $_GET['reason'] == 'nocss' ) {
				$message	= __( 'The import settings could not be applied. Please try again.', 'gppro' );
			}

			// display the message
			echo '<div id="message" class="error">';
			echo '<p>'.esc_attr( $message ).'</p>';
			echo '</div>';

			return;

		}

		// checks passed, display the message
		if ( isset( $_GET['uploaded'] ) && $_GET['uploaded'] == 'success' ) {

			echo '<div id="message" class="updated">';
				echo '<p>'.__( 'Your settings have been updated', 'gppro' ).'</p>';
			echo '</div>';

			return;

		}

		return;

	}

	/**
	 * various actions / filters to target specific plugins that may cause issues in the preview
	 *
	 * example: if a plugin has a function to add a tracking script, we don't want it
	 * so we can unhook it if the preview is active
	 *
	 *		if ( has_action( 'wp_footer', 'my_function_name' ) ) {
	 *			remove_action( 'wp_footer', 'my_function_name' );
	 *		}
	 *
	 * @return void
	 */
	public function plugin_compat() {

		if ( ! isset( $_GET['gppro-preview'] ) ) {
			return;
		}

		// allow users to bail before the plugin compatibility settings
		if ( true === apply_filters( 'gppro_disable_plugin_compat', false ) ) {
			return;
		}

		// core plugin compatibility settings
		define( 'QUICK_CACHE_ALLOWED', FALSE );
		define( 'QM_DISABLED', true );

		// some plugins we know cause problems
		remove_action( 'wp_footer', 'insert_smart_layer' ); // added 09/22/2014 plugin version 1.0.10

		// allow developers to add more plugin compatibility hooks
		do_action( 'gppro_after_plugin_compat' );

	}

	/**
	 * Fetch the license data and return whatever may be needed
	 *
	 * @return string license data
	 */
	static function license_data( $key = false ) {

		// set a default option table name with filter
		$option	= apply_filters( 'gppro_core_update_key', 'gppro_core_active' );

		// fetch the data
		$data	= get_option( $option );

		// bail if none returned
		if ( ! $data || empty( $data ) ) {
			return false;
		}

		// return all of it if no key specified
		if ( ! $key ) {
			return $data;
		}

		// return the key if it exists
		if ( $key && isset( $data[ $key ] ) ) {
			return $data[ $key ];
		}

		// bail
		return false;

	}

	/**
	 * call update function for plugin
	 * @return mixed bool
	 */
	public function edd_core_update() {

		// retrieve our license key from the DB
		$data	= self::license_data();

		// filter for checking license in other data
		$data	= apply_filters( 'gppro_core_update_data', $data );

		// bail if no license data is present
		if ( ! $data || empty( $data ) ) {
			return;
		}

		// bail if license isn't valid
		if ( ! isset( $data['status'] ) || empty( $data['status'] ) || $data['status'] !== 'valid' ) {
			return;
		}

		// bail if no actual key
		if ( ! isset( $data['license'] ) || empty( $data['license'] ) ) {
			return;
		}

		// setup the updater
		$edd_updater = new EDD_SL_Plugin_Updater( GPP_STORE_URL, __FILE__, array(
				'version' 	=> GPP_VER, 					// current version number
				'license' 	=> $data['license'],			// license key (used get_option above to retrieve from DB)
				'item_name' => GPP_ITEM_NAME, 				// name of this plugin
				'author' 	=> 'Genesis Design Palette'		// author of this plugin
			)
		);

	}

/// end class
}


// Instantiate our class
$Genesis_Palette_Pro = Genesis_Palette_Pro::getInstance();
