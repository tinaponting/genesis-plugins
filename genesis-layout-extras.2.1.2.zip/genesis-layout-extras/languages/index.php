<?php
/**
 * Do not put custom translations here. They will be deleted on 'Genesis Layout Extras' updates!
 *
 * Keep custom 'Genesis Layout Extras' translations in '/wp-content/languages/genesis-layout-extras/'
 */
